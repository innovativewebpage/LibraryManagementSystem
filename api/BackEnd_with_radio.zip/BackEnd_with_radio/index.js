const express = require('express')
const app = express();

const db = require('./db');


app.use(express.json())

const ProductRoute = require('./productRoutes');
app.use('/app/data',ProductRoute);

//Start the server
var port =5000;

app.listen(port,function(){
	console.log('server start on port' + port);
});

